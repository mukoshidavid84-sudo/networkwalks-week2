# Passive & Active Web Reconnaissance — `networkwalks.com`
**Program:** NETWORK WALKS — Cybersecurity Internship 2026 (Week 2 - Project Module 1)  
**Author:** David Mukoshi  
**Environment:** Kali Linux  

---

## 📋 Overview
This repository documents reconnaissance and footprinting performed against `networkwalks.com` to identify domain registration details, hosting infrastructure, DNS records, HTTP response headers, web technologies, and Web Application Firewall (WAF) protections.

## 📂 Repository Structure
```text
├── README.md
├── images/
│   ├── 01_whois.png
│   ├── 02_whatweb.png
│   ├── 03_nslookup.png
│   ├── 04_curl_headers.png
│   ├── 05_wafw00f.png
│   └── 06_dnsrecon.png
└── outputs/
    ├── 01_whois.txt
    ├── 02_whatweb.txt
    ├── 03_nslookup.txt
    ├── 04_curl_headers.txt
    ├── 05_wafw00f.txt
    └── 06_dnsrecon.txt
```

---

## 🔍 Reconnaissance Steps & Findings

### 1. WHOIS Domain Lookup
* **Command:** `whois networkwalks.com`
* **Raw Output:** [`outputs/01_whois.txt`](outputs/01_whois.txt)
* **Key Findings:**
  * **Registrar:** GoDaddy.com, LLC (IANA ID: 146)
  * **Creation Date:** November 6, 2019 | **Expiry Date:** November 6, 2027
  * **Name Servers:** `NS6135.HOSTGATOR.COM`, `NS6136.HOSTGATOR.COM`
  * **DNSSEC:** Unsigned
  * **Domain Status:** `clientDeleteProhibited`, `clientRenewProhibited`, `clientTransferProhibited`, `clientUpdateProhibited`

![WHOIS Output](images/01_whois.png)

---

### 2. Web Technology Fingerprinting (`whatweb`)
* **Command:** `whatweb networkwalks.com`
* **Raw Output:** [`outputs/02_whatweb.txt`](outputs/02_whatweb.txt)
* **Key Findings:**
  * **Web Server:** Apache (HTTP redirects via `301 Moved Permanently` to HTTPS `200 OK`)
  * **CMS & Plugins:** WordPress 7.1.4, WordPress Download Manager 3.3.76
  * **Frontend Libraries:** Bootstrap 7.1.4, jQuery 3.7.1
  * **Hosting Location:** United States (`192.232.216.135`)
  * **Contact Email Discovered:** `info@networkwalks.com`

![WhatWeb Output](images/02_whatweb.png)

---

### 3. DNS Resolution (`nslookup`)
* **Command:** `nslookup networkwalks.com`
* **Raw Output:** [`outputs/03_nslookup.txt`](outputs/03_nslookup.txt)
* **Key Findings:**
  * **Resolved IPv4 Address (A Record):** `192.232.216.135` (Non-authoritative answer)

![NSLookup Output](images/03_nslookup.png)

---

### 4. HTTP Response Headers (`curl`)
* **Command:** `curl -I https://networkwalks.com`
* **Raw Output:** [`outputs/04_curl_headers.txt`](outputs/04_curl_headers.txt)
* **Key Findings:**
  * **Protocol & Status:** `HTTP/2 200`
  * **Server / Caching:** Apache backend with Nginx caching (`x-nginx-cache: WordPress`, `x-endurance-cache-level: 0`)
  * **Security Headers Observed:** `permissions-policy`, `referrer-policy: no-referrer-when-downgrade`, `HttpOnly` & `Secure` flags enabled on `__wpdm_client` session cookie.

![Curl Headers Output](images/04_curl_headers.png)

---

### 5. Web Application Firewall Detection (`wafw00f`)
* **Command:** `wafw00f networkwalks.com`
* **Raw Output:** [`outputs/05_wafw00f.txt`](outputs/05_wafw00f.txt)
* **Key Findings:**
  * **WAF Detected:** **ModSecurity (SpiderLabs)** protecting `https://networkwalks.com` (detected in 2 requests).

![WAFW00F Output](images/05_wafw00f.png)

---

### 6. Comprehensive DNS Enumeration (`dnsrecon`)
* **Command:** `dnsrecon -d networkwalks.com`
* **Raw Output:** [`outputs/06_dnsrecon.txt`](outputs/06_dnsrecon.txt)
* **Key Findings:**
  * **SOA Record:** `ns6135.hostgator.com` (`50.87.144.87`)
  * **NS Record:** `ns6136.hostgator.com` (`192.232.216.131`)
  * **MX Record:** `mail.networkwalks.com` (`192.232.216.135`)
  * **TXT Records:** SPF policy (`v=spf1 +a +mx +ip4:50.87.144.87 ...`) and `google-site-verification` token
  * **SRV Records:** `_autodiscover._tcp.networkwalks.com` pointing to `cpanelemaildiscovery.cpanel.net`

![DNSRecon Output](images/06_dnsrecon.png)
