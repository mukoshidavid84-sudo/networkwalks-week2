#!/bin/bash
mkdir -p outputs
whois networkwalks.com > outputs/01_whois.txt
whatweb networkwalks.com > outputs/02_whatweb.txt
nslookup networkwalks.com > outputs/03_nslookup.txt
curl -I https://networkwalks.com > outputs/04_curl_headers.txt
wafw00f networkwalks.com > outputs/05_wafw00f.txt
dnsrecon -d networkwalks.com > outputs/06_dnsrecon.txt
echo "All 6 text output files generated inside outputs/!"
